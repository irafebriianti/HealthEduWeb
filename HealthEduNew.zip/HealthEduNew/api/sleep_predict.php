<?php
// ============================================================
//  HEALTHEDU — api/sleep_predict.php
//  POST { heart_rate, bmi_category, stress_level }
//  → { success, data: { quality, label, color, tips } }
// ============================================================
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('Method tidak diizinkan.', 405);
}

$body = json_decode(file_get_contents('php://input'), true);

$heart_rate   = isset($body['heart_rate'])   ? (float) $body['heart_rate']   : null;
$bmi_category = isset($body['bmi_category']) ? trim($body['bmi_category'])   : null;
$stress_level = isset($body['stress_level']) ? (float) $body['stress_level'] : null;

// Validasi input
if ($heart_rate === null || $bmi_category === null || $stress_level === null) {
    jsonError('heart_rate, bmi_category, dan stress_level wajib diisi.');
}
if ($heart_rate < 30 || $heart_rate > 200) {
    jsonError('heart_rate harus antara 30–200 bpm.');
}
$validBMI = ['Normal', 'Normal Weight', 'Overweight', 'Obese'];
if (!in_array($bmi_category, $validBMI)) {
    jsonError('bmi_category tidak valid. Pilihan: ' . implode(', ', $validBMI));
}
if ($stress_level < 1 || $stress_level > 10) {
    jsonError('stress_level harus antara 1–10.');
}

// ── Coba Python dulu, fallback ke logika PHP jika gagal ──
$usedPython = false;
$result = null;

// Cari python3 atau python di PATH
$pythonBin = null;
foreach (['python3', 'python', 'python3.exe', 'python.exe'] as $bin) {
    $which = shell_exec("which $bin 2>/dev/null || where $bin 2>nul");
    if ($which && trim($which) !== '') {
        $pythonBin = trim(explode("\n", $which)[0]);
        break;
    }
}

if ($pythonBin) {
    $script = escapeshellarg(__DIR__ . '/sleep_predict.py');
    $hr     = escapeshellarg((string) $heart_rate);
    $bmi    = escapeshellarg($bmi_category);
    $sl     = escapeshellarg((string) $stress_level);
    $cmd    = "$pythonBin $script $hr $bmi $sl 2>&1";
    $output = shell_exec($cmd);

    if ($output) {
        $decoded = json_decode(trim($output), true);
        if ($decoded && !isset($decoded['error'])) {
            $result = $decoded;
            $usedPython = true;
        }
    }
}

// ── Fallback: hitung dengan rumus sederhana (tanpa Python/ML) ──
if (!$result) {
    // Skor dasar dari tiap faktor (skala 0–10)
    $hrScore    = $heart_rate <= 60  ? 10 :
                 ($heart_rate <= 75  ?  9 :
                 ($heart_rate <= 85  ?  7 :
                 ($heart_rate <= 100 ?  5 : 3)));

    $bmiScore   = in_array($bmi_category, ['Normal', 'Normal Weight']) ? 10 :
                 ($bmi_category === 'Overweight' ? 6 : 4);

    $stressScore = $stress_level <= 3 ? 10 :
                  ($stress_level <= 5 ?  8 :
                  ($stress_level <= 7 ?  5 : 3));

    $quality = round(($hrScore * 0.3 + $bmiScore * 0.2 + $stressScore * 0.5), 2);
    $quality = max(1.0, min(10.0, $quality));

    if ($quality >= 8)       { $label = 'Sangat Baik'; $color = '#10b981'; }
    elseif ($quality >= 6.5) { $label = 'Baik';        $color = '#3b82f6'; }
    elseif ($quality >= 5)   { $label = 'Cukup';       $color = '#f59e0b'; }
    else                     { $label = 'Buruk';        $color = '#ef4444'; }

    $tips = [];
    if ($stress_level >= 7)
        $tips[] = 'Kurangi stres dengan meditasi atau relaksasi sebelum tidur.';
    if ($heart_rate > 80)
        $tips[] = 'Detak jantung tinggi — hindari kafein 4 jam sebelum tidur.';
    if (in_array($bmi_category, ['Overweight', 'Obese']))
        $tips[] = 'Menjaga berat badan ideal dapat meningkatkan kualitas tidur.';
    if ($stress_level < 5 && $heart_rate <= 75)
        $tips[] = 'Pertahankan gaya hidup sehatmu untuk tidur berkualitas!';
    if (empty($tips))
        $tips[] = 'Jaga pola tidur teratur dan hindari layar sebelum tidur.';

    $result = compact('quality', 'label', 'color', 'tips');
}

// ── Simpan ke log jika user sedang login (token dikirim) ──
$token = '';
$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
if (str_starts_with($auth, 'Bearer ')) {
    $token = trim(substr($auth, 7));
}
if (!$token) {
    $token = $body['token'] ?? '';
}

if ($token) {
    $db = getDB();
    $s  = $db->prepare('SELECT user_id, expires_at FROM sessions WHERE token = ?');
    $s->execute([$token]);
    $sess = $s->fetch();
    if ($sess && new DateTime() <= new DateTime($sess['expires_at'])) {
        $userId = (int) $sess['user_id'];
        $ins = $db->prepare(
            'INSERT INTO sleep_log (user_id, heart_rate, bmi_category, stress_level, quality, label)
             VALUES (?, ?, ?, ?, ?, ?)'
        );
        $ins->execute([$userId, $heart_rate, $bmi_category, $stress_level, $result['quality'], $result['label']]);
    }
}

jsonSuccess($result, 'Prediksi berhasil.');
