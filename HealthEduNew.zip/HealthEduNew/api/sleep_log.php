<?php
// ============================================================
//  HEALTHEDU — api/sleep_log.php
//  GET   ?token=xxx                       → ambil riwayat prediksi tidur
//  POST  { token, action:'delete', id }   → hapus satu
//  POST  { token, action:'clear' }        → hapus semua
// ============================================================
require_once __DIR__ . '/config.php';

$db = getDB();

// ─── GET: ambil riwayat ─────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $token = $_GET['token'] ?? '';
    if (!$token) jsonError('Token diperlukan.', 401);

    $s = $db->prepare('SELECT user_id, expires_at FROM sessions WHERE token = ?');
    $s->execute([$token]);
    $sess = $s->fetch();
    if (!$sess || new DateTime() > new DateTime($sess['expires_at'])) {
        jsonError('Sesi tidak valid.', 401);
    }
    $userId = (int) $sess['user_id'];

    $rows = $db->prepare(
        'SELECT id, heart_rate, bmi_category, stress_level, quality, label, recorded_at
           FROM sleep_log
          WHERE user_id = ?
          ORDER BY recorded_at DESC
          LIMIT 15'
    );
    $rows->execute([$userId]);
    jsonSuccess($rows->fetchAll());
}

// ─── POST: hapus ─────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = requireAuth();
    $body   = json_decode(file_get_contents('php://input'), true);
    $action = $body['action'] ?? '';

    if ($action === 'delete') {
        $id = (int)($body['id'] ?? 0);
        if (!$id) jsonError('ID tidak valid.');
        $db->prepare('DELETE FROM sleep_log WHERE id = ? AND user_id = ?')
           ->execute([$id, $userId]);
        jsonSuccess([], 'Riwayat prediksi tidur dihapus.');
    }

    if ($action === 'clear') {
        $db->prepare('DELETE FROM sleep_log WHERE user_id = ?')->execute([$userId]);
        jsonSuccess([], 'Semua riwayat prediksi tidur dihapus.');
    }

    jsonError('Aksi tidak dikenali.');
}

jsonError('Method tidak diizinkan.', 405);
