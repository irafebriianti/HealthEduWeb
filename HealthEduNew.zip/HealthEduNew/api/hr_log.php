<?php
// ============================================================
//  HEALTHEDU — api/hr_log.php
//  GET   ?token=xxx                                                    → ambil riwayat
//  POST  { token, bpm, max, min, cond, condLabel, zone, status }       → simpan
//  POST  { token, action:'delete', id }                                → hapus satu
//  POST  { token, action:'clear' }                                     → hapus semua
// ============================================================
require_once __DIR__ . '/config.php';

$db = getDB();

// ─── GET: ambil riwayat ─────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $token = $_GET['token'] ?? '';
    if (!$token) jsonError('Token diperlukan.', 401);

    // resolve token → user_id
    $s = $db->prepare('SELECT user_id, expires_at FROM sessions WHERE token = ?');
    $s->execute([$token]);
    $sess = $s->fetch();
    if (!$sess || new DateTime() > new DateTime($sess['expires_at'])) {
        jsonError('Sesi tidak valid.', 401);
    }
    $userId = (int) $sess['user_id'];

    $rows = $db->prepare(
        'SELECT id, bpm, bpm_max, bpm_min, condition_key, condition_label, zone, status, recorded_at
           FROM hr_log
          WHERE user_id = ?
          ORDER BY recorded_at DESC
          LIMIT 15'
    );
    $rows->execute([$userId]);
    jsonSuccess($rows->fetchAll());
}

// ─── POST: simpan / hapus ───────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = requireAuth();
    $body   = json_decode(file_get_contents('php://input'), true);
    $action = $body['action'] ?? 'save';

    if ($action === 'delete') {
        $id = (int)($body['id'] ?? 0);
        if (!$id) jsonError('ID tidak valid.');
        $db->prepare('DELETE FROM hr_log WHERE id = ? AND user_id = ?')
           ->execute([$id, $userId]);
        jsonSuccess([], 'Riwayat detak jantung dihapus.');
    }

    if ($action === 'clear') {
        $db->prepare('DELETE FROM hr_log WHERE user_id = ?')->execute([$userId]);
        jsonSuccess([], 'Semua riwayat detak jantung dihapus.');
    }

    // Default: simpan
    $bpm        = (int)($body['bpm']        ?? 0);
    $bpmMax     = (int)($body['max']        ?? $bpm);
    $bpmMin     = (int)($body['min']        ?? $bpm);
    $condKey    = trim($body['cond']        ?? '');
    $condLabel  = trim($body['condLabel']   ?? '');
    $zone       = trim($body['zone']        ?? '');
    $status     = $body['status']           ?? 'normal';

    if (!$bpm || !$condKey || !$condLabel || !$zone) jsonError('Data tidak lengkap.');
    if (!in_array($status, ['normal','warning','danger'])) $status = 'normal';

    // Batasi 15 entri per user
    $count = (int) $db->query("SELECT COUNT(*) FROM hr_log WHERE user_id = $userId")->fetchColumn();
    if ($count >= 15) {
        // Hapus yang paling lama
        $db->prepare(
            'DELETE FROM hr_log WHERE user_id = ? ORDER BY recorded_at ASC LIMIT 1'
        )->execute([$userId]);
    }

    $ins = $db->prepare(
        'INSERT INTO hr_log (user_id, bpm, bpm_max, bpm_min, condition_key, condition_label, zone, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    $ins->execute([$userId, $bpm, $bpmMax, $bpmMin, $condKey, $condLabel, $zone, $status]);

    jsonSuccess(['id' => (int)$db->lastInsertId()], 'Detak jantung berhasil disimpan.');
}

jsonError('Method tidak diizinkan.', 405);
