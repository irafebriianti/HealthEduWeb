<?php
/**
 * hr_proxy.php — Proxy untuk data sensor ESP32
 * Letakkan file ini di folder api/ kamu
 * 
 * Cara pakai dari JS:
 *   fetch('api/hr_proxy.php?ip=192.168.1.100&port=80')
 * 
 * PHP yang fetch ke ESP32 tidak terkena CORS browser.
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$ip   = $_GET['ip']   ?? '';
$port = $_GET['port'] ?? '80';

// Validasi IP sederhana
if (!$ip || !filter_var($ip, FILTER_VALIDATE_IP)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'IP tidak valid']);
    exit;
}

$url = "http://{$ip}:{$port}/data";

// Fetch ke ESP32 dari sisi server (tidak kena CORS)
$ctx = stream_context_create([
    'http' => [
        'timeout'        => 3,          // timeout 3 detik
        'ignore_errors'  => true,
    ]
]);

$raw = @file_get_contents($url, false, $ctx);

if ($raw === false) {
    http_response_code(502);
    echo json_encode([
        'success' => false,
        'message' => 'Tidak bisa terhubung ke ESP32. Pastikan IP benar dan satu jaringan WiFi.'
    ]);
    exit;
}

$data = json_decode($raw, true);

if (!$data) {
    http_response_code(502);
    echo json_encode(['success' => false, 'message' => 'Respons sensor tidak valid']);
    exit;
}

echo json_encode([
    'success' => true,
    'bpm'     => (int)($data['bpm']    ?? 0),
    'signal'  => (int)($data['signal'] ?? 0),
]);
