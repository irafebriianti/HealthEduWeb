#!/usr/bin/env python3
# ============================================================
#  HEALTHEDU — api/sleep_predict.py
#  Dipanggil oleh sleep_predict.php
#  Input  (argv): heart_rate  bmi_category  stress_level
#  Output (stdout): JSON { quality: float, label: str, tips: [...] }
# ============================================================
import sys, json, os

BASE = os.path.dirname(os.path.abspath(__file__))

try:
    import joblib
    import numpy as np
except ImportError as e:
    print(json.dumps({"error": f"Dependensi Python tidak ditemukan: {e}"}))
    sys.exit(1)

try:
    model   = joblib.load(os.path.join(BASE, 'sleep_quality_model.pkl'))
    bmi_map = joblib.load(os.path.join(BASE, 'bmi_mapping.pkl'))
except Exception as e:
    print(json.dumps({"error": f"Gagal memuat model: {e}"}))
    sys.exit(1)

if len(sys.argv) < 4:
    print(json.dumps({"error": "Argumen kurang: heart_rate bmi_category stress_level"}))
    sys.exit(1)

try:
    heart_rate    = float(sys.argv[1])
    bmi_category  = sys.argv[2].strip()
    stress_level  = float(sys.argv[3])
except ValueError as e:
    print(json.dumps({"error": f"Input tidak valid: {e}"}))
    sys.exit(1)

bmi_encoded = bmi_map.get(bmi_category, bmi_map.get('Normal', 0))

import pandas as pd
X = pd.DataFrame([[heart_rate, bmi_encoded, stress_level]],
                 columns=['Heart Rate', 'BMI Category', 'Stress Level'])

quality = round(float(model.predict(X)[0]), 2)
quality = max(1.0, min(10.0, quality))

# Label kualitas tidur
if quality >= 8:
    label = "Sangat Baik"
    color = "#10b981"
elif quality >= 6.5:
    label = "Baik"
    color = "#3b82f6"
elif quality >= 5:
    label = "Cukup"
    color = "#f59e0b"
else:
    label = "Buruk"
    color = "#ef4444"

# Tips berdasarkan faktor
tips = []
if stress_level >= 7:
    tips.append("Kurangi stres dengan meditasi atau relaksasi sebelum tidur.")
if heart_rate > 80:
    tips.append("Detak jantung tinggi — hindari kafein 4 jam sebelum tidur.")
if bmi_category in ("Overweight", "Obese"):
    tips.append("Menjaga berat badan ideal dapat meningkatkan kualitas tidur.")
if stress_level < 5 and heart_rate <= 75:
    tips.append("Pertahankan gaya hidup sehatmu untuk tidur berkualitas!")

print(json.dumps({
    "quality": quality,
    "label": label,
    "color": color,
    "tips": tips
}))
