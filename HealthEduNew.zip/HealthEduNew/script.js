/* ============================================
   HEALTHEDU — script.js
   ✅ Terhubung ke MySQL via PHP API
   ============================================ */

// ─────────────────────────────────────────────
// CONFIG API
// Sesuaikan BASE_URL dengan lokasi folder api/ di server kamu
// Contoh lokal:  'api'
// Contoh server: 'https://domain.com/healthedu/api'
// ─────────────────────────────────────────────
const API = 'api';   // ← ubah sesuai path server kamu

// ─────────────────────────────────────────────
// STATE
// ─────────────────────────────────────────────
let bmiGender  = 'male';
let tdeeGender = 'male';
let calGoal    = 2000;

// Data disimpan di memori (sync dari server saat login)
let foodLog = [];
let bmiLog  = [];
let weekLog = {};

// Auth state — token disimpan di localStorage
let authToken = localStorage.getItem('he_token') || null;
let authUser  = JSON.parse(localStorage.getItem('he_user') || 'null');

// ─────────────────────────────────────────────
// MENU DATA (statis, tidak berubah)
// ─────────────────────────────────────────────
const MENUS = [
  { emoji:'🥣', name:'Oatmeal Buah',          cat:'sarapan', cal:320, p:12, k:58, l:6,  desc:'Oat, pisang, stroberi, madu, susu rendah lemak' },
  { emoji:'🍳', name:'Telur + Roti Gandum',   cat:'sarapan', cal:385, p:22, k:35, l:16, desc:'2 telur rebus, 2 lembar roti gandum, selai kacang' },
  { emoji:'🥛', name:'Greek Yogurt Parfait',  cat:'sarapan', cal:295, p:18, k:42, l:5,  desc:'Yogurt Yunani, granola, blueberry, madu' },
  { emoji:'🍱', name:'Nasi Merah + Ayam Bakar',cat:'siang',  cal:510, p:38, k:62, l:10, desc:'100g nasi merah, 150g ayam bakar tanpa kulit, lalapan' },
  { emoji:'🥗', name:'Salad Tuna Mediterania',cat:'siang',   cal:340, p:32, k:18, l:14, desc:'Tuna kalengan, selada, tomat cherry, lemon dressing' },
  { emoji:'🍜', name:'Soto Ayam Bening',       cat:'siang',  cal:420, p:28, k:48, l:9,  desc:'Ayam suwir, bihun, telur, sayuran, kaldu bening' },
  { emoji:'🐟', name:'Ikan Panggang + Sayur',  cat:'malam',  cal:380, p:42, k:22, l:12, desc:'200g ikan kembung panggang, brokoli, wortel, jeruk nipis' },
  { emoji:'🥩', name:'Tempe Tahu Bacem',       cat:'malam',  cal:310, p:20, k:30, l:11, desc:'Tempe, tahu, kecap rendah garam, bawang, rempah' },
  { emoji:'🥦', name:'Cap Cay Sayur + Tahu',   cat:'malam',  cal:265, p:14, k:35, l:7,  desc:'Aneka sayuran, tahu, saus tiram rendah sodium' },
  { emoji:'🍌', name:'Pisang + Selai Kacang',  cat:'snack',  cal:190, p:5,  k:30, l:7,  desc:'1 pisang sedang + 1 sdm selai kacang alami' },
  { emoji:'🥜', name:'Mix Kacang Panggang',    cat:'snack',  cal:175, p:5,  k:8,  l:15, desc:'Almond, walnut, kacang mede tanpa garam (30g)' },
  { emoji:'🍎', name:'Buah Segar Campur',      cat:'snack',  cal:95,  p:1,  k:24, l:0,  desc:'Apel, pepaya, melon, semangka potong (150g)' },
];

const CAT_TAG  = { sarapan:'Sarapan', siang:'Makan Siang', malam:'Makan Malam', snack:'Snack' };
const CAT_CSS  = { sarapan:'tag-sarapan', siang:'tag-siang', malam:'tag-malam', snack:'tag-snack' };
const TYPE_EMOJI = { Sarapan:'🌅', 'Makan Siang':'☀️', 'Makan Malam':'🌙', Snack:'🍎' };

// ─────────────────────────────────────────────
// API HELPER
// ─────────────────────────────────────────────
async function apiPost(endpoint, data = {}) {
  if (authToken) data.token = authToken;
  const res = await fetch(`${API}/${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return res.json();
}

async function apiGet(endpoint, params = {}) {
  if (authToken) params.token = authToken;
  const qs  = new URLSearchParams(params).toString();
  const res = await fetch(`${API}/${endpoint}${qs ? '?' + qs : ''}`);
  return res.json();
}

// ─────────────────────────────────────────────
// INIT
// ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  updateNavAuth();
  renderMenuGrid();
  animateCounters();
  navScrollEffect();

  if (authToken) {
    await loadAllDataFromServer();
  } else {
    // Fallback ke localStorage jika belum login
    foodLog = JSON.parse(localStorage.getItem('he_food') || '[]');
    bmiLog  = JSON.parse(localStorage.getItem('he_bmi')  || '[]');
    weekLog = JSON.parse(localStorage.getItem('he_week') || '{}');
  }

  renderFoodLog();
  renderBMILog();
  updateLogSummary();

  // Render ulang HR log jika sudah di-load dari server (login)
  if (authToken && document.getElementById('arLogBody')) {
    arRenderLog();
    arRenderTrend();
    document.getElementById('arAICount').textContent = arLogData.length;
  }
});

// ─────────────────────────────────────────────
// LOAD DATA DARI SERVER
// ─────────────────────────────────────────────
async function loadAllDataFromServer() {
  try {
    // Food log hari ini
    const foodRes = await apiGet('food.php', { date: todayISO() });
    if (foodRes.success) {
      foodLog = foodRes.data.map(f => ({
        id:   f.id,
        name: f.name,
        cal:  parseInt(f.calories),
        type: f.meal_type,
        p:    parseInt(f.protein_g),
        k:    parseInt(f.carbs_g),
        l:    parseInt(f.fat_g),
        time: new Date(f.recorded_at).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit' }),
      }));
    }

    // BMI log
    const bmiRes = await apiGet('bmi.php');
    if (bmiRes.success) {
      bmiLog = bmiRes.data.map(b => ({
        id:    b.id,
        bmi:   b.bmi,
        cat:   b.category,
        color: bmiColor(parseFloat(b.bmi)),
        bg:    bmiBg(parseFloat(b.bmi)),
        w:     b.weight, h: b.height, age: b.age, gender: b.gender,
        date:  new Date(b.recorded_at).toLocaleDateString('id-ID', { day:'numeric', month:'short', year:'numeric' }),
        time:  new Date(b.recorded_at).toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit' }),
      }));
    }

    // Week log untuk bar chart
    const weekRes = await apiGet('food.php', { action: 'week' });
    if (weekRes.success) {
      weekLog = {};
      weekRes.data.forEach(r => { weekLog[r.log_date] = parseInt(r.total_cal); });
    }

    // TDEE tersimpan (restore calGoal)
    const tdeeRes = await apiGet('tdee.php');
    if (tdeeRes.success && tdeeRes.data && tdeeRes.data.tdee) {
      calGoal = parseInt(tdeeRes.data.tdee);
    }

    // Heart Rate log (AI Heart Rate Monitor)
    const hrRes = await apiGet('hr_log.php');
    if (hrRes.success) {
      arLogData = hrRes.data.map(e => ({
        id: e.id,
        datetime: new Date(e.recorded_at).toLocaleString('id-ID'),
        bpm: parseInt(e.bpm),
        max: parseInt(e.bpm_max),
        min: parseInt(e.bpm_min),
        cond: e.condition_key,
        condLabel: e.condition_label,
        zone: e.zone,
        status: e.status,
      }));
    }
  } catch (e) {
    console.warn('Gagal muat data dari server, pakai lokal.', e);
  }
}

// ─────────────────────────────────────────────
// NAVIGATION (SPA)
// ─────────────────────────────────────────────
function navigate(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const target = document.getElementById('page-' + page);
  if (target) {
    target.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  if (page === 'log') {
    setTimeout(() => {
      updateLogSummary();
      renderBarChart();
      renderLineChart();
    }, 50);
  }
}

function scrollToFAQ() {
  navigate('home');
  setTimeout(() => {
    const el = document.getElementById('faq-anchor');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  }, 100);
}

// ─────────────────────────────────────────────
// NAVBAR
// ─────────────────────────────────────────────
function navScrollEffect() {
  window.addEventListener('scroll', () => {
    const nav = document.getElementById('navbar');
    nav.style.boxShadow = window.scrollY > 40
      ? '0 4px 24px rgba(0,0,0,.1)' : 'none';
  });
}

function toggleNav() {
  const m = document.getElementById('navMobile');
  m.classList.toggle('open');
}

// Tampilkan nama user / tombol logout jika sudah login
function updateNavAuth() {
  const navAuth = document.getElementById('navAuth');
  if (!navAuth) return;

  if (authUser) {
    navAuth.innerHTML = `
      <span style="font-weight:600;color:#064e3b;font-size:.9rem">
        <i class="fas fa-user-circle"></i> ${authUser.name.split(' ')[0]}
      </span>
      <button class="nav-btn-login" onclick="handleLogout()">
        <i class="fas fa-sign-out-alt"></i> Keluar
      </button>`;
  }
  // Jika belum login, HTML default dari index.html sudah benar
}

// ─────────────────────────────────────────────
// ANIMATED COUNTERS
// ─────────────────────────────────────────────
function animateCounters() {
  document.querySelectorAll('.count-up').forEach(el => {
    const target = parseInt(el.getAttribute('data-to'));
    const dur  = 1600;
    const step = target / (dur / 16);
    let cur    = 0;
    const t = setInterval(() => {
      cur = Math.min(cur + step, target);
      el.textContent = target >= 1000
        ? (cur / 1000).toFixed(1).replace('.0','') + 'K'
        : Math.floor(cur);
      if (cur >= target) clearInterval(t);
    }, 16);
  });
}

// ─────────────────────────────────────────────
// FAQ
// ─────────────────────────────────────────────
function toggleFAQ(btn) {
  const ans    = btn.nextElementSibling;
  const isOpen = btn.classList.contains('open');
  document.querySelectorAll('.fq').forEach(b => {
    b.classList.remove('open');
    b.nextElementSibling.classList.remove('open');
  });
  if (!isOpen) { btn.classList.add('open'); ans.classList.add('open'); }
}

// ─────────────────────────────────────────────
// CALC TABS
// ─────────────────────────────────────────────
function switchCalcTab(tab) {
  ['bmi','tdee'].forEach(t => {
    document.getElementById('tab-' + t).classList.toggle('active', t === tab);
    document.getElementById('cpanel-' + t).classList.toggle('active', t === tab);
  });
}

// ─────────────────────────────────────────────
// GENDER
// ─────────────────────────────────────────────
function setGender(g, mode) {
  if (mode === 'bmi') {
    bmiGender = g;
    document.getElementById('gbtn-male').classList.toggle('active',   g === 'male');
    document.getElementById('gbtn-female').classList.toggle('active', g === 'female');
  } else {
    tdeeGender = g;
    document.getElementById('tgbtn-male').classList.toggle('active',   g === 'male');
    document.getElementById('tgbtn-female').classList.toggle('active', g === 'female');
  }
}

// ─────────────────────────────────────────────
// BMI CALCULATOR
// ─────────────────────────────────────────────
async function calcBMI() {
  const w  = parseFloat(document.getElementById('b-weight').value);
  const hc = parseFloat(document.getElementById('b-height').value);
  const a  = parseFloat(document.getElementById('b-age').value);

  if (!w || !hc || !a)              { showToast('⚠️ Lengkapi semua data!'); return; }
  if (w < 20 || w > 300)            { showToast('⚠️ Berat tidak valid (20–300 kg)'); return; }
  if (hc < 50 || hc > 250)          { showToast('⚠️ Tinggi tidak valid (50–250 cm)'); return; }

  const h   = hc / 100;
  const bmi = w / (h * h);
  const bmiR = bmi.toFixed(1);

  let cat, color, bg, tip;
  if      (bmi < 18.5) { cat='Kekurangan Berat Badan'; color='#2563eb'; bg='#eff6ff'; tip='💡 Tingkatkan asupan kalori dengan makanan bergizi seperti kacang-kacangan, alpukat, dan protein berkualitas.'; }
  else if (bmi < 25)   { cat='Berat Badan Ideal';       color='#059669'; bg='#f0fdf4'; tip='✅ Pertahankan pola makan seimbang dan olahraga rutin. Anda dalam kondisi ideal!'; }
  else if (bmi < 30)   { cat='Kelebihan Berat Badan';   color='#d97706'; bg='#fffbeb'; tip='💡 Kurangi asupan 300–500 kkal/hari dan tingkatkan aktivitas fisik 150 menit/minggu.'; }
  else                 { cat='Obesitas';                 color='#dc2626'; bg='#fff1f2'; tip='⚠️ Disarankan berkonsultasi dengan dokter untuk program penurunan berat badan yang aman.'; }

  const base = bmiGender === 'male' ? 50 : 45.5;
  const iMin = (base + 0.91 * (hc - 152.4)).toFixed(1);
  const iMax = (base + 0.91 * (hc - 152.4) + 10).toFixed(1);

  document.getElementById('bmi-res').innerHTML = `
    <div class="bmi-res-content">
      <div class="bmi-circle" style="background:${bg};border-color:${color}">
        <span class="bmi-circle-val" style="color:${color}">${bmiR}</span>
        <span class="bmi-circle-lbl" style="color:${color}">BMI</span>
      </div>
      <span class="bmi-cat-badge" style="background:${bg};color:${color}">${cat}</span>
      <div class="bmi-detail-grid">
        <div class="bdi"><strong>${w} kg</strong><small>Berat Badan</small></div>
        <div class="bdi"><strong>${hc} cm</strong><small>Tinggi Badan</small></div>
        <div class="bdi"><strong>${iMin}–${iMax} kg</strong><small>Berat Ideal</small></div>
        <div class="bdi"><strong>${a} thn</strong><small>Usia</small></div>
      </div>
      <div class="bmi-tip">${tip}</div>
    </div>`;

  // Needle
  const needle = document.getElementById('bmi-needle');
  needle.style.display = 'block';
  let pct = bmi < 18.5 ? (bmi/18.5)*25
           : bmi < 25   ? 25 + ((bmi-18.5)/6.5)*25
           : bmi < 30   ? 50 + ((bmi-25)/5)*25
                        : 75 + Math.min(((bmi-30)/10)*25, 23);
  pct = Math.max(2, Math.min(97, pct));
  setTimeout(() => { needle.style.left = pct + '%'; }, 80);

  // Simpan ke server (atau localStorage jika belum login)
  await saveBMILog(bmiR, cat, color, bg, w, hc, a);
  showToast('✅ BMI berhasil dihitung!');
}

// ─────────────────────────────────────────────
// TDEE CALCULATOR
// ─────────────────────────────────────────────
async function calcTDEE() {
  const w  = parseFloat(document.getElementById('t-weight').value);
  const h  = parseFloat(document.getElementById('t-height').value);
  const a  = parseFloat(document.getElementById('t-age').value);
  const af = parseFloat(document.getElementById('t-activity').value);

  if (!w || !h || !a) { showToast('⚠️ Lengkapi semua data!'); return; }

  const bmr  = tdeeGender === 'male'
    ? 88.362 + (13.397*w) + (4.799*h) - (5.677*a)
    : 447.593 + (9.247*w) + (3.098*h) - (4.330*a);

  const tdee  = Math.round(bmr * af);
  const lose  = Math.round(tdee - 500);
  const gain  = Math.round(tdee + 300);
  const prot  = Math.round((tdee * 0.30) / 4);
  const carbs = Math.round((tdee * 0.40) / 4);
  const fat   = Math.round((tdee * 0.30) / 9);

  const actNames = { '1.2':'Tidak Aktif','1.375':'Ringan','1.55':'Sedang','1.725':'Aktif','1.9':'Sangat Aktif' };

  document.getElementById('tdee-res').innerHTML = `
    <div class="tdee-res-content">
      <div class="tdee-big">${tdee.toLocaleString('id-ID')}</div>
      <div class="tdee-sub">kkal/hari · Aktivitas ${actNames[af.toString()] || 'Sedang'}</div>
      <div class="tdee-goals">
        <div class="tg-item"><strong style="color:#dc2626">${lose.toLocaleString('id-ID')}</strong><small>📉 Turun Berat</small></div>
        <div class="tg-item"><strong style="color:#059669">${tdee.toLocaleString('id-ID')}</strong><small>⚖️ Jaga Berat</small></div>
        <div class="tg-item"><strong style="color:#2563eb">${gain.toLocaleString('id-ID')}</strong><small>📈 Naik Berat</small></div>
      </div>
      <div class="bmi-detail-grid">
        <div class="bdi"><strong>${prot}g</strong><small>Protein/hari</small></div>
        <div class="bdi"><strong>${carbs}g</strong><small>Karbo/hari</small></div>
        <div class="bdi"><strong>${fat}g</strong><small>Lemak/hari</small></div>
        <div class="bdi"><strong>${Math.round(bmr)}</strong><small>BMR Dasar</small></div>
      </div>
      <div class="bmi-tip">💡 Gunakan angka TDEE ini sebagai acuan asupan kalori harian sesuai tujuanmu. Target sudah diperbarui di Log!</div>
    </div>`;

  calGoal = tdee;
  updateLogSummary();

  // Simpan TDEE ke server
  if (authToken) {
    try {
      await apiPost('tdee.php', {
        tdee, bmr: Math.round(bmr), activity: af,
        weight: w, height: h, age: a, gender: tdeeGender,
      });
    } catch(e) { console.warn('Gagal simpan TDEE', e); }
  }

  showToast('🔥 TDEE berhasil dihitung!');
}

// ─────────────────────────────────────────────
// MENU GRID
// ─────────────────────────────────────────────
function renderMenuGrid() {
  const grid = document.getElementById('menuGrid');
  grid.innerHTML = MENUS.map(m => `
    <div class="mcard" data-cat="${m.cat}">
      <div class="mcard-emoji">${m.emoji}</div>
      <div class="mcard-body">
        <span class="mcard-tag ${CAT_CSS[m.cat]}">${CAT_TAG[m.cat]}</span>
        <h4>${m.name}</h4>
        <p>${m.desc}</p>
        <div class="mcard-macros">
          <span class="mcal"><i class="fas fa-fire"></i> ${m.cal} kkal</span>
          <span class="mmacro">P: ${m.p}g</span>
          <span class="mmacro">K: ${m.k}g</span>
          <span class="mmacro">L: ${m.l}g</span>
        </div>
      </div>
      <button class="mcard-btn" onclick="addFoodFromMenu('${m.name}',${m.cal},'${CAT_TAG[m.cat]}',${m.p},${m.k},${m.l})" title="Tambah ke log">
        <i class="fas fa-plus"></i>
      </button>
    </div>`).join('');
}

function filterMenu(cat, btn) {
  document.querySelectorAll('.mf').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.querySelectorAll('.mcard').forEach(c => {
    c.classList.toggle('hidden', cat !== 'all' && c.dataset.cat !== cat);
  });
}

// ─────────────────────────────────────────────
// FOOD LOG
// ─────────────────────────────────────────────
async function addFoodFromMenu(name, cal, type, p, k, l) {
  await addFoodEntry(name, cal, type, p, k, l);
  showToast(`✅ ${name} ditambahkan ke log!`);
}

async function addFoodEntry(name, cal, type, p=0, k=0, l=0) {
  const entry = {
    id:   Date.now(),   // temp id, akan diganti id dari server jika login
    name, cal: parseInt(cal), type, p, k, l,
    time: new Date().toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit' }),
  };

  // Simpan ke server jika login
  if (authToken) {
    try {
      const res = await apiPost('food.php', {
        name, calories: cal, meal_type: type,
        protein_g: p, carbs_g: k, fat_g: l,
        log_date: todayISO(),
      });
      if (res.success) entry.id = res.data.id;
    } catch(e) { console.warn('Gagal simpan makanan ke server', e); }
  } else {
    // Fallback localStorage
    const local = JSON.parse(localStorage.getItem('he_food') || '[]');
    local.push(entry);
    localStorage.setItem('he_food', JSON.stringify(local));
  }

  foodLog.push(entry);
  renderFoodLog();
  updateLogSummary();
  renderBarChart();
  renderDonut();
  updateWeekLog();
}

function renderFoodLog() {
  const el = document.getElementById('logList');
  if (!el) return;
  if (!foodLog.length) {
    el.innerHTML = `<div class="log-empty-state"><i class="fas fa-clipboard-list"></i><p>Belum ada catatan. Tambah dari Menu atau klik "+ Tambah Manual".</p></div>`;
    return;
  }
  el.innerHTML = foodLog.map(f => `
    <div class="log-item">
      <div class="li-emoji">${TYPE_EMOJI[f.type] || '🍽️'}</div>
      <div class="li-info">
        <div class="li-name">${f.name}</div>
        <div class="li-meta">${f.type} · ${f.time}</div>
      </div>
      <span class="li-cal">${f.cal} kkal</span>
      <button class="li-del" onclick="removeFoodItem(${f.id})"><i class="fas fa-times"></i></button>
    </div>`).join('');
}

async function removeFoodItem(id) {
  if (authToken) {
    try {
      await apiPost('food.php', { action: 'delete', id });
    } catch(e) { console.warn('Gagal hapus makanan', e); }
  } else {
    const local = JSON.parse(localStorage.getItem('he_food') || '[]').filter(f => f.id !== id);
    localStorage.setItem('he_food', JSON.stringify(local));
  }

  foodLog = foodLog.filter(f => f.id !== id);
  renderFoodLog();
  updateLogSummary();
  renderBarChart();
  renderDonut();
  showToast('🗑️ Dihapus dari log.');
}

async function clearFoodLog() {
  if (!foodLog.length) { showToast('Log sudah kosong!'); return; }
  if (!confirm('Hapus semua log makanan hari ini?')) return;

  if (authToken) {
    try {
      await apiPost('food.php', { action: 'clear', date: todayISO() });
    } catch(e) { console.warn('Gagal hapus semua', e); }
  } else {
    localStorage.setItem('he_food', '[]');
  }

  foodLog = [];
  renderFoodLog();
  updateLogSummary();
  renderBarChart();
  renderDonut();
  showToast('🗑️ Semua log dihapus.');
}

function updateLogSummary() {
  const total  = foodLog.reduce((s, f) => s + f.cal, 0);
  const remain = Math.max(0, calGoal - total);
  const pct    = Math.min(100, Math.round((total / calGoal) * 100));

  const ls = id => document.getElementById(id);
  if (ls('ls-total'))  ls('ls-total').textContent  = total.toLocaleString('id-ID');
  if (ls('ls-meals'))  ls('ls-meals').textContent  = foodLog.length;
  if (ls('ls-goal'))   ls('ls-goal').textContent   = calGoal.toLocaleString('id-ID');
  if (ls('ls-remain')) ls('ls-remain').textContent = remain.toLocaleString('id-ID');

  const fill  = ls('calProgFill');
  const pctEl = ls('calProgPct');
  if (fill) {
    fill.style.width      = pct + '%';
    fill.style.background = pct >= 100
      ? 'linear-gradient(to right, #f59e0b, #ef4444)'
      : 'linear-gradient(to right, #10b981, #3b82f6)';
  }
  if (pctEl) pctEl.textContent = `${pct}% tercapai`;

  renderDonut();
}

// ─────────────────────────────────────────────
// MODAL: TAMBAH MANUAL
// ─────────────────────────────────────────────
function openAddFood() {
  document.getElementById('addFoodModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal() {
  document.getElementById('addFoodModal').classList.remove('open');
  document.body.style.overflow = '';
}
function closeModalBg(e) {
  if (e.target === e.currentTarget) closeModal();
}
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeModal();
});

async function submitAddFood() {
  const name = document.getElementById('mf-name').value.trim();
  const cal  = parseInt(document.getElementById('mf-cal').value);
  const type = document.getElementById('mf-type').value;
  if (!name)          { showToast('⚠️ Nama makanan harus diisi!'); return; }
  if (!cal || cal<=0) { showToast('⚠️ Kalori tidak valid!'); return; }

  const k = Math.round((cal * .40) / 4);
  const p = Math.round((cal * .30) / 4);
  const l = Math.round((cal * .30) / 9);

  await addFoodEntry(name, cal, type, p, k, l);
  closeModal();
  document.getElementById('mf-name').value = '';
  document.getElementById('mf-cal').value  = '';
  showToast(`✅ ${name} ditambahkan!`);
}

// ─────────────────────────────────────────────
// BMI LOG
// ─────────────────────────────────────────────
async function saveBMILog(bmi, cat, color, bg, w, h, age) {
  const entry = {
    id: Date.now(), bmi, cat, color, bg, w, h, age,
    date: new Date().toLocaleDateString('id-ID', { day:'numeric', month:'short', year:'numeric' }),
    time: new Date().toLocaleTimeString('id-ID', { hour:'2-digit', minute:'2-digit' }),
  };

  if (authToken) {
    try {
      const res = await apiPost('bmi.php', {
        bmi, category: cat, weight: w, height: h, age, gender: bmiGender,
      });
      if (res.success) entry.id = res.data.id;
    } catch(e) { console.warn('Gagal simpan BMI ke server', e); }
  } else {
    const local = JSON.parse(localStorage.getItem('he_bmi') || '[]');
    local.unshift(entry);
    if (local.length > 15) local.splice(15);
    localStorage.setItem('he_bmi', JSON.stringify(local));
  }

  bmiLog.unshift(entry);
  if (bmiLog.length > 15) bmiLog = bmiLog.slice(0, 15);
  renderBMILog();
  renderLineChart();
}

function renderBMILog() {
  const el = document.getElementById('bmiLogList');
  if (!el) return;
  if (!bmiLog.length) {
    el.innerHTML = `<div class="log-empty-state"><i class="fas fa-weight-scale"></i><p>Belum ada riwayat. Hitung BMI di halaman Kalkulator.</p></div>`;
    return;
  }
  el.innerHTML = bmiLog.map(b => `
    <div class="bmi-log-item">
      <div class="bmi-badge" style="background:${b.bg};color:${b.color}">
        <span class="bmi-badge-val">${b.bmi}</span>
        <span class="bmi-badge-lbl">BMI</span>
      </div>
      <div class="bmi-info">
        <div class="bmi-info-name" style="color:${b.color}">${b.cat}</div>
        <div class="bmi-info-meta">${b.w}kg · ${b.h}cm · ${b.age}thn · ${b.date} ${b.time}</div>
      </div>
      <button class="bmi-del" onclick="removeBMIEntry(${b.id})"><i class="fas fa-times"></i></button>
    </div>`).join('');
}

async function removeBMIEntry(id) {
  if (authToken) {
    try {
      await apiPost('bmi.php', { action: 'delete', id });
    } catch(e) { console.warn('Gagal hapus BMI', e); }
  } else {
    const local = JSON.parse(localStorage.getItem('he_bmi') || '[]').filter(b => b.id !== id);
    localStorage.setItem('he_bmi', JSON.stringify(local));
  }

  bmiLog = bmiLog.filter(b => b.id !== id);
  renderBMILog();
  renderLineChart();
  showToast('🗑️ Riwayat dihapus.');
}

async function clearBMILog() {
  if (!bmiLog.length) { showToast('Riwayat sudah kosong!'); return; }
  if (!confirm('Hapus semua riwayat BMI?')) return;

  if (authToken) {
    try {
      await apiPost('bmi.php', { action: 'clear' });
    } catch(e) { console.warn('Gagal hapus BMI', e); }
  } else {
    localStorage.setItem('he_bmi', '[]');
  }

  bmiLog = [];
  renderBMILog();
  renderLineChart();
  showToast('🗑️ Riwayat BMI dihapus.');
}

// ─────────────────────────────────────────────
// WEEK LOG
// ─────────────────────────────────────────────
function updateWeekLog() {
  const today = todayISO();
  const total = foodLog.reduce((s, f) => s + f.cal, 0);
  weekLog[today] = total;

  if (!authToken) {
    // Simpan lokal jika belum login
    const keys = Object.keys(weekLog).sort();
    if (keys.length > 30) keys.slice(0, keys.length - 30).forEach(k => delete weekLog[k]);
    localStorage.setItem('he_week', JSON.stringify(weekLog));
  }
  // Jika login, server sudah update otomatis saat add/remove food
}

// ─────────────────────────────────────────────
// DONUT CHART
// ─────────────────────────────────────────────
function renderDonut() {
  const totCal = foodLog.reduce((s,f) => s+f.cal, 0);
  const totK   = foodLog.reduce((s,f) => s+f.k, 0);
  const totP   = foodLog.reduce((s,f) => s+f.p, 0);
  const totL   = foodLog.reduce((s,f) => s+f.l, 0);

  const cCenter = document.getElementById('donut-center');
  if (cCenter) cCenter.textContent = totCal.toLocaleString('id-ID');

  const legC = document.getElementById('leg-carb');
  const legP = document.getElementById('leg-prot');
  const legF = document.getElementById('leg-fat');
  if (legC) legC.textContent = totK + 'g';
  if (legP) legP.textContent = totP + 'g';
  if (legF) legF.textContent = totL + 'g';

  const circ      = 439.82;
  const totMacro  = totK * 4 + totP * 4 + totL * 9 || 1;
  const kLen      = (totK * 4 / totMacro) * circ;
  const pLen      = (totP * 4 / totMacro) * circ;
  const lLen      = (totL * 9 / totMacro) * circ;

  const dC = document.getElementById('donut-carb');
  const dP = document.getElementById('donut-prot');
  const dF = document.getElementById('donut-fat');
  if (!dC || !dP || !dF) return;

  if (totCal === 0) {
    [dC,dP,dF].forEach(el => el.setAttribute('stroke-dasharray','0 439.82'));
    return;
  }

  dC.setAttribute('stroke-dasharray', `${kLen} ${circ - kLen}`);
  dC.setAttribute('stroke-dashoffset', '109.96');
  const pOffset = 109.96 - kLen;
  dP.setAttribute('stroke-dasharray', `${pLen} ${circ - pLen}`);
  dP.setAttribute('stroke-dashoffset', pOffset);
  const lOffset = pOffset - pLen;
  dF.setAttribute('stroke-dasharray', `${lLen} ${circ - lLen}`);
  dF.setAttribute('stroke-dashoffset', lOffset);
}

// ─────────────────────────────────────────────
// BAR CHART
// ─────────────────────────────────────────────
function renderBarChart() {
  const container = document.getElementById('barChartArea');
  if (!container) return;

  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const key   = d.toISOString().split('T')[0];
    const label = d.toLocaleDateString('id-ID', { weekday:'short' });
    days.push({ label, cal: weekLog[key] || 0, key });
  }

  const maxCal = Math.max(...days.map(d => d.cal), calGoal, 500);

  container.innerHTML = days.map(day => {
    const heightPct = (day.cal / maxCal) * 100;
    const targetPct = (calGoal / maxCal) * 100;
    const barClass  = day.cal === 0 ? 'bar-low' : day.cal > calGoal ? 'bar-over' : 'bar-ok';
    const isToday   = day.key === todayISO();

    return `
      <div class="bar-col">
        <div class="bar-val">${day.cal > 0 ? day.cal.toLocaleString('id-ID') : ''}</div>
        <div class="bar-stack ${barClass}" style="height:${heightPct}%;min-height:${day.cal>0?'4px':'0'}">
          <div class="bar-target-line" style="bottom:${(targetPct / heightPct) * 100}%;display:${heightPct > 0 ? 'block':'none'}"></div>
        </div>
        <div class="bar-label" style="font-weight:${isToday?'800':'600'};color:${isToday?'#10b981':'#94a3b8'}">${day.label}${isToday?' ●':''}</div>
      </div>`;
  }).join('');
}

// ─────────────────────────────────────────────
// LINE CHART (BMI trend)
// ─────────────────────────────────────────────
function renderLineChart() {
  const area  = document.getElementById('lineChartArea');
  const empty = document.getElementById('lineEmpty');
  if (!area) return;

  if (bmiLog.length < 2) {
    if (empty) empty.style.display = 'flex';
    const old = area.querySelector('svg');
    if (old) old.remove();
    return;
  }

  if (empty) empty.style.display = 'none';

  const data = [...bmiLog].reverse();
  const vals = data.map(d => parseFloat(d.bmi));
  const minV = Math.max(10, Math.min(...vals) - 2);
  const maxV = Math.max(...vals) + 2;

  const W = area.clientWidth || 600;
  const H = 200;
  const PAD = { t:20, r:20, b:40, l:40 };
  const plotW = W - PAD.l - PAD.r;
  const plotH = H - PAD.t - PAD.b;

  const xScale = i => PAD.l + (i / (data.length - 1)) * plotW;
  const yScale = v => PAD.t + plotH - ((v - minV) / (maxV - minV)) * plotH;

  const pts      = data.map((d, i) => [xScale(i), yScale(parseFloat(d.bmi))]);
  const linePath = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(' ');
  const fillPath = linePath + ` L${pts[pts.length-1][0]},${PAD.t+plotH} L${pts[0][0]},${PAD.t+plotH} Z`;

  const ySteps  = 4;
  const yLabels = Array.from({length: ySteps+1}, (_,i) => {
    const v = minV + (i/ySteps) * (maxV - minV);
    const y = yScale(v);
    return `<text x="${PAD.l - 6}" y="${y+4}" text-anchor="end" font-size="10" fill="#94a3b8" font-family="Plus Jakarta Sans" font-weight="600">${v.toFixed(1)}</text>
            <line x1="${PAD.l}" y1="${y}" x2="${PAD.l+plotW}" y2="${y}" stroke="#f1f5f9" stroke-width="1"/>`;
  }).join('');

  const xLabels = data.map((d, i) => `
    <text x="${xScale(i)}" y="${H - 10}" text-anchor="middle" font-size="10" fill="#94a3b8" font-family="Plus Jakarta Sans" font-weight="600">${d.date}</text>`).join('');

  const dots = pts.map((p, i) => `
    <circle cx="${p[0]}" cy="${p[1]}" r="6" fill="#10b981" stroke="white" stroke-width="2.5"/>
    <text x="${p[0]}" y="${p[1] - 12}" text-anchor="middle" font-size="11" fill="#064e3b" font-family="Plus Jakarta Sans" font-weight="800">${data[i].bmi}</text>`).join('');

  const zoneTop    = yScale(24.9);
  const zoneBottom = yScale(18.5);

  const svg = `
    <svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#10b981" stop-opacity="0.2"/>
          <stop offset="100%" stop-color="#10b981" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <rect x="${PAD.l}" y="${zoneTop}" width="${plotW}" height="${zoneBottom - zoneTop}" fill="rgba(16,185,129,0.07)" rx="2"/>
      <text x="${PAD.l + plotW - 4}" y="${zoneTop + 14}" text-anchor="end" font-size="10" fill="#10b981" font-family="Plus Jakarta Sans" font-weight="700" opacity="0.7">Normal</text>
      ${yLabels}
      <path d="${fillPath}" fill="url(#lineGrad)"/>
      <path d="${linePath}" fill="none" stroke="#10b981" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
      ${xLabels}
      ${dots}
    </svg>`;

  const old = area.querySelector('svg');
  if (old) old.remove();
  area.insertAdjacentHTML('afterbegin', svg);
}

// ─────────────────────────────────────────────
// TOAST
// ─────────────────────────────────────────────
let toastTimer;
function showToast(msg) {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3000);
}

// ─────────────────────────────────────────────
// AUTH HANDLERS
// ─────────────────────────────────────────────
async function handleLogin() {
  const email = document.getElementById('login-email').value.trim();
  const pass  = document.getElementById('login-pass').value;

  if (!email || !pass)           { showToast('⚠️ Email dan password harus diisi!'); return; }
  if (!email.includes('@'))      { showToast('⚠️ Format email tidak valid!'); return; }
  if (pass.length < 6)           { showToast('⚠️ Password minimal 6 karakter!'); return; }

  showToast('⏳ Memproses...');

  try {
    const res = await apiPost('login.php', { email, password: pass });
    if (!res.success) { showToast('❌ ' + res.message); return; }

    // Simpan token & user
    authToken = res.data.token;
    authUser  = res.data.user;
    localStorage.setItem('he_token', authToken);
    localStorage.setItem('he_user', JSON.stringify(authUser));

    // Muat data dari server
    await loadAllDataFromServer();
    renderFoodLog();
    renderBMILog();
    updateLogSummary();
    updateNavAuth();

    showToast(`✅ Login berhasil! Halo, ${authUser.name.split(' ')[0]}!`);
    setTimeout(() => navigate('home'), 800);
  } catch(e) {
    showToast('❌ Gagal terhubung ke server.');
  }
}

async function handleSignup() {
  const name    = document.getElementById('signup-name').value.trim();
  const email   = document.getElementById('signup-email').value.trim();
  const pass    = document.getElementById('signup-pass').value;
  const confirm = document.getElementById('signup-confirm').value;
  const agree   = document.getElementById('signup-agree').checked;

  if (!name)                          { showToast('⚠️ Nama lengkap harus diisi!'); return; }
  if (!email || !email.includes('@')) { showToast('⚠️ Format email tidak valid!'); return; }
  if (pass.length < 8)                { showToast('⚠️ Password minimal 8 karakter!'); return; }
  if (pass !== confirm)               { showToast('⚠️ Konfirmasi password tidak cocok!'); return; }
  if (!agree)                         { showToast('⚠️ Setujui syarat & ketentuan terlebih dahulu!'); return; }

  showToast('⏳ Membuat akun...');

  try {
    const res = await apiPost('signup.php', { name, email, password: pass });
    if (!res.success) { showToast('❌ ' + res.message); return; }

    authToken = res.data.token;
    authUser  = res.data.user;
    localStorage.setItem('he_token', authToken);
    localStorage.setItem('he_user', JSON.stringify(authUser));

    updateNavAuth();
    showToast(`🎉 Akun berhasil dibuat! Selamat datang, ${name}!`);
    setTimeout(() => navigate('home'), 800);
  } catch(e) {
    showToast('❌ Gagal terhubung ke server.');
  }
}

async function handleLogout() {
  if (authToken) {
    try { await apiPost('logout.php', { token: authToken }); } catch(e) {}
  }
  authToken = null;
  authUser  = null;
  localStorage.removeItem('he_token');
  localStorage.removeItem('he_user');

  foodLog = [];
  bmiLog  = [];
  weekLog = {};

  updateNavAuth();
  renderFoodLog();
  renderBMILog();
  updateLogSummary();
  showToast('👋 Kamu telah keluar.');
  navigate('home');
}

function togglePass(inputId, btn) {
  const input = document.getElementById(inputId);
  const icon  = btn.querySelector('i');
  if (input.type === 'password') {
    input.type = 'text';
    icon.classList.replace('fa-eye', 'fa-eye-slash');
  } else {
    input.type = 'password';
    icon.classList.replace('fa-eye-slash', 'fa-eye');
  }
}

// ─────────────────────────────────────────────
// UTILS
// ─────────────────────────────────────────────
function todayISO() {
  return new Date().toISOString().split('T')[0];
}

function bmiColor(bmi) {
  if (bmi < 18.5) return '#2563eb';
  if (bmi < 25)   return '#059669';
  if (bmi < 30)   return '#d97706';
  return '#dc2626';
}
function bmiBg(bmi) {
  if (bmi < 18.5) return '#eff6ff';
  if (bmi < 25)   return '#f0fdf4';
  if (bmi < 30)   return '#fffbeb';
  return '#fff1f2';
}

// ═══════════════════════════════════════════════
// ARTIKEL & HEART RATE MONITOR MODULE
// ═══════════════════════════════════════════════

// ─── AR STATE ───
let arCond = 'resting';
let arConnected = false;
let arDemo = false;
let arMonitoring = false;
let arPollInterval = null;
let arDemoInterval = null;
let arSessionTimer = null;
let arCurrentBPM = 0;
let arBpmHistory = [];
let arSigHistory = [];
let arSessionStart = null;
let arLogData = [];
let arLogFilter = 'all';
let arEspURL = '';

const arCondLabels = {
  resting:'Istirahat', exercise:'Sedang Olahraga', post_exercise:'Habis Olahraga',
  coffee:'Habis Ngopi', stressed:'Stres/Cemas', sick:'Kurang Sehat',
  wakeup:'Baru Bangun', relax:'Relaksasi'
};
const arCondRanges = {
  resting:      { low:60, high:100, veryHigh:110, veryLow:50 },
  exercise:     { low:100, high:180, veryHigh:190, veryLow:90 },
  post_exercise:{ low:80, high:130, veryHigh:150, veryLow:60 },
  coffee:       { low:65, high:110, veryHigh:125, veryLow:55 },
  stressed:     { low:70, high:115, veryHigh:130, veryLow:55 },
  sick:         { low:60, high:110, veryHigh:130, veryLow:50 },
  wakeup:       { low:55, high:95,  veryHigh:110, veryLow:45 },
  relax:        { low:55, high:90,  veryHigh:105, veryLow:45 }
};

// ─── TAB SWITCHER ───
function switchArTab(tab) {
  ['monitor','artikel'].forEach(t => {
    document.getElementById('artab-' + t).classList.toggle('active', t === tab);
    document.getElementById('arpanel-' + t).classList.toggle('active', t === tab);
  });
  if (tab === 'artikel') renderArArticles();
}

// ─── CONDITION ───
function arSelectCond(btn) {
  document.querySelectorAll('.ar-cond-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  arCond = btn.dataset.cond;
  showToast('Kondisi: ' + arCondLabels[arCond]);
}

// ─── CONNECT (lewat proxy) ───
function arConnect() {
  const ip   = document.getElementById('arEspIP').value.trim();
  const port = document.getElementById('arEspPort').value.trim() || '80';
  if (!ip) { showToast('⚠️ Masukkan IP address dulu!'); return; }
 
  arDemo = false;
 
  // Simpan IP & port untuk polling nanti
  arEspIP   = ip;
  arEspPort = port;
 
  arSetConnStatus('connecting', 'Menghubungkan ke ' + ip + ':' + port + '...');
 
  // Pakai proxy PHP agar tidak kena CORS browser
  const proxyURL = `${API}/hr_proxy.php?ip=${encodeURIComponent(ip)}&port=${encodeURIComponent(port)}`;
 
  fetch(proxyURL)
    .then(r => r.json())
    .then(data => {
      if (data.success) {
        arConnected = true;
        arSetConnStatus('ok', `✅ Terhubung ke ESP32 (${ip}:${port})`);
        arEnableStart(true);
        showToast('✅ Sensor terhubung!');
      } else {
        throw new Error(data.message || 'Gagal');
      }
    })
    .catch(err => {
      arSetConnStatus('err', '❌ Gagal terhubung. Cek IP/WiFi & pastikan satu jaringan.');
      showToast('❌ ' + (err.message || 'Tidak bisa terhubung ke sensor'));
    });
}

function arActivateDemo() {
  arDemo = true; arConnected = true;
  arSetConnStatus('ok', '🧪 Mode Demo Aktif');
  arEnableStart(true);
  showToast('🧪 Mode demo aktif!');
}

function arSetConnStatus(state, text) {
  const dot = document.getElementById('arConnDot');
  const el = document.getElementById('arConnStatus');
  const colors = { ok:'#10b981', err:'#ef4444', connecting:'#f59e0b' };
  dot.style.background = colors[state] || '#cbd5e1';
  if (state === 'connecting') dot.style.animation = 'pulse-dot 1s infinite';
  else dot.style.animation = 'none';
  document.getElementById('arConnText').textContent = text;
  el.style.background = state === 'ok' ? '#f0fdf4' : state === 'err' ? '#fff5f5' : '#fffbeb';
  el.style.color = state === 'ok' ? '#059669' : state === 'err' ? '#dc2626' : '#92400e';
}

function arEnableStart(on) {
  const s = document.getElementById('arBtnStart');
  s.disabled = !on;
  s.style.opacity = on ? '1' : '.5';
  s.style.cursor = on ? 'pointer' : 'not-allowed';
}

// ─── MONITOR ───
function arStartMonitor() {
  if (!arConnected) return;
  arMonitoring = true;
  arBpmHistory = []; arSigHistory = [];
  arSessionStart = Date.now();
  document.getElementById('arBtnStart').disabled = true;
  document.getElementById('arBtnStart').style.opacity = '.5';
  document.getElementById('arBtnStop').disabled = false;
  document.getElementById('arBtnStop').style.opacity = '1';
  document.getElementById('arBtnSave').disabled = false;
  document.getElementById('arBtnSave').style.opacity = '1';
  document.getElementById('arHeartAnim').style.animation = 'heartbeat-fast .6s ease-in-out infinite';
  arSessionTimer = setInterval(arUpdateDur, 1000);
  if (arDemo) arStartDemo(); else arPollInterval = setInterval(arFetchData, 1000);
}

function arStopMonitor() {
  arMonitoring = false;
  clearInterval(arPollInterval); clearInterval(arDemoInterval); clearInterval(arSessionTimer);
  document.getElementById('arBtnStart').disabled = false;
  document.getElementById('arBtnStart').style.opacity = '1';
  document.getElementById('arBtnStop').disabled = true;
  document.getElementById('arBtnStop').style.opacity = '.5';
  document.getElementById('arHeartAnim').style.animation = 'heartbeat 1s ease-in-out infinite';
  if (arCurrentBPM > 0) { arShowNotif(arCurrentBPM); arShowSuggestions(arCurrentBPM); }
}

// ─── FETCH DATA DARI SENSOR (lewat proxy) ───
function arFetchData() {
  const proxyURL = `${API}/hr_proxy.php?ip=${encodeURIComponent(arEspIP)}&port=${encodeURIComponent(arEspPort)}`;
 
  fetch(proxyURL)
    .then(r => r.json())
    .then(data => {
      if (data.success && data.bpm > 0) {
        arUpdateBPM(data.bpm, data.signal);
      }
    })
    .catch(() => {
      // Abaikan error polling — koneksi bisa sesekali putus
    });
}

let arDemoBase = 72, arDemoTarget = 72, arDemoStep = 0;
function arStartDemo() {
  const base = { resting:68, exercise:145, post_exercise:105, coffee:88, stressed:95, sick:85, wakeup:72, relax:62 };
  arDemoBase = base[arCond] || 70;
  arDemoTarget = arDemoBase;
  arDemoInterval = setInterval(() => {
    arDemoStep++;
    if (arDemoStep % 15 === 0) arDemoTarget = arDemoBase + (Math.random()-.5) * 20;
    const bpm = Math.round(Math.max(40, Math.min(200, arDemoTarget + (Math.random()-.5)*6)));
    const sig = Math.round(1500 + Math.random()*800);
    arUpdateBPM(bpm, sig);
  }, 800);
}

function arUpdateBPM(bpm, sig) {
  arCurrentBPM = bpm;
  arBpmHistory.push(bpm);
  if (sig !== undefined) arSigHistory.push(sig);
  if (arBpmHistory.length > 60) arBpmHistory.shift();
  if (arSigHistory.length > 60) arSigHistory.shift();

  document.getElementById('arBpmDisplay').textContent = bpm;

  // Zone
  let zone, zoneName, bpmColor = '#dc2626', bgGrad = 'linear-gradient(135deg,#fff5f5,#fff0f0)', borderColor = '#fca5a5';
  if (bpm < 60)       { zone='low';    zoneName='Sangat Rendah'; }
  else if (bpm < 100) { zone='rest';   zoneName='Istirahat Normal'; bpmColor='#059669'; bgGrad='linear-gradient(135deg,#f0fdf4,#ecfdf5)'; borderColor='#6ee7b7'; }
  else if (bpm < 130) { zone='fat';    zoneName='Pembakaran Lemak'; bpmColor='#1d4ed8'; bgGrad='linear-gradient(135deg,#eff6ff,#dbeafe)'; borderColor='#93c5fd'; }
  else if (bpm < 160) { zone='cardio'; zoneName='Zona Kardio'; bpmColor='#d97706'; bgGrad='linear-gradient(135deg,#fffbeb,#fef3c7)'; borderColor='#fcd34d'; }
  else                { zone='peak';   zoneName='Zona Puncak'; }

  const main = document.getElementById('arMonMain');
  main.style.background = bgGrad;
  main.style.borderColor = borderColor;
  document.getElementById('arBpmDisplay').style.color = bpmColor;

  const zb = document.getElementById('arZoneBadge');
  zb.style.visibility = 'visible';
  document.getElementById('arZoneName').textContent = zoneName;

  // Stats
  const mx = Math.max(...arBpmHistory), mn = Math.min(...arBpmHistory);
  const avg = Math.round(arBpmHistory.reduce((a,b)=>a+b,0)/arBpmHistory.length);
  document.getElementById('arStatMax').textContent = mx;
  document.getElementById('arStatMin').textContent = mn;
  document.getElementById('arStatAvg').textContent = avg;
  if (sig) document.getElementById('arSigBadge').textContent = 'ADC: ' + sig;

  arDrawSignal();
  arCheckLiveNotif(bpm);
}

function arDrawSignal() {
  const canvas = document.getElementById('arSigCanvas');
  if (!canvas) return;
  const w = canvas.offsetWidth || 300, h = 110;
  canvas.width = w; canvas.height = h;
  const c = canvas.getContext('2d');
  c.fillStyle = '#0f172a'; c.fillRect(0, 0, w, h);
  if (arSigHistory.length < 2) return;
  const mn = Math.min(...arSigHistory), mx = Math.max(...arSigHistory), range = mx - mn || 1;
  c.shadowColor = '#10b981'; c.shadowBlur = 5;
  c.strokeStyle = '#10b981'; c.lineWidth = 2; c.beginPath();
  arSigHistory.forEach((v, i) => {
    const x = (i/(arSigHistory.length-1))*w;
    const y = h - ((v-mn)/range)*(h-12)-6;
    i===0 ? c.moveTo(x,y) : c.lineTo(x,y);
  });
  c.stroke();
  c.shadowBlur = 0;
  const last = arSigHistory[arSigHistory.length-1];
  const lx = w, ly = h - ((last-mn)/range)*(h-12)-6;
  c.lineTo(lx,h); c.lineTo(0,h); c.closePath();
  const g = c.createLinearGradient(0,0,0,h);
  g.addColorStop(0,'rgba(16,185,129,.2)'); g.addColorStop(1,'rgba(16,185,129,0)');
  c.fillStyle = g; c.fill();
}

function arUpdateDur() {
  if (!arSessionStart) return;
  const s = Math.floor((Date.now()-arSessionStart)/1000);
  const m = Math.floor(s/60);
  document.getElementById('arStatDur').textContent = m > 0 ? `${m}m ${s%60}s` : `${s}s`;
}

let arLastNotif = 0;
function arCheckLiveNotif(bpm) {
  const now = Date.now();
  if (now - arLastNotif < 8000) return;
  const r = arCondRanges[arCond];
  if (bpm > r.veryHigh || bpm < r.veryLow) { arLastNotif = now; arShowNotif(bpm); }
}

function arShowNotif(bpm) {
  const r = arCondRanges[arCond];
  const el = document.getElementById('arNotif');
  el.style.display = 'block';
  let bg, borderColor, title, body;
  if (bpm >= r.veryHigh)  { bg='#fff5f5'; borderColor='#ef4444'; title='⚠️ Detak Jantung Sangat Tinggi!'; body=`BPM ${bpm} jauh di atas batas. Istirahat segera, minum air, napas perlahan.`; }
  else if (bpm > r.high)  { bg='#fffbeb'; borderColor='#f59e0b'; title='⚡ Detak Jantung Agak Tinggi'; body=`BPM ${bpm} sedikit di atas normal (${r.low}–${r.high}). Istirahat sejenak disarankan.`; }
  else if (bpm < r.veryLow){ bg='#fff5f5'; borderColor='#ef4444'; title='⚠️ Detak Jantung Sangat Rendah!'; body=`BPM ${bpm} sangat rendah. Hubungi tenaga medis jika disertai pusing/lemas.`; }
  else if (bpm < r.low)   { bg='#eff6ff'; borderColor='#3b82f6'; title='ℹ️ Detak Agak Rendah'; body=`BPM ${bpm} di bawah normal. Wajar pada atlet, pantau terus.`; }
  else                    { bg='#f0fdf4'; borderColor='#10b981'; title='✅ Detak Jantung Normal'; body=`BPM ${bpm} dalam rentang aman (${r.low}–${r.high} bpm). Pertahankan!`; }
  el.style.background = bg; el.style.borderLeftColor = borderColor;
  el.innerHTML = `<div style="font-weight:700;margin-bottom:4px;color:#1e293b">${title}</div><div style="font-size:.85rem;color:#64748b">${body}</div>`;
}

function arShowSuggestions(bpm) {
  const r = arCondRanges[arCond];
  let cat = bpm > r.veryHigh ? 'danger' : (bpm > r.high || bpm < r.low) ? 'warning' : 'normal';
  const sugs = {
    normal: { resting:[['💧','Minum Air','8 gelas per hari'],['🧘','Relaksasi','Nikmati momen ini'],['🥗','Makan Sehat','Buah & sayur segar'],['😴','Tidur Cukup','7–9 jam per malam']],
      exercise:[['💧','Hidrasi','200ml tiap 20 menit'],['🫁','Napas','Jaga irama napas'],['⌚','Jaga Zona','Pertahankan intensitas'],['🔥','Lanjutkan!','Zona optimal aktif']],
      default:[['💧','Hidrasi','Minum air cukup'],['🧘','Relax','Ambil napas dalam'],['🥗','Nutrisi','Makan bergizi'],['😴','Istirahat','Tidur berkualitas']] },
    warning: { default:[['💧','Minum Air','Segera minum air putih'],['🧘','Pernapasan 4-7-8','Tarik 4s, tahan 7s, buang 8s'],['🛑','Kurangi Aktivitas','Istirahat sejenak'],['👨‍⚕️','Pantau','Perhatikan gejalamu']] },
    danger:  { default:[['🚨','Istirahat Segera','Hentikan semua aktivitas'],['📞','Hubungi Bantuan','Beritahu orang sekitar'],['💧','Tetap Tenang','Napas perlahan'],['🏥','Pertimbangkan IGD','Jika berlanjut']] }
  };
  const card = document.getElementById('arSugCard');
  const grid = document.getElementById('arSugGrid');
  card.style.display = 'block';
  document.getElementById('arSugLabel').textContent = `Saran untuk kondisi "${arCondLabels[arCond]}" dengan BPM ${bpm}`;
  const s = cat === 'danger' ? sugs.danger.default : cat === 'warning' ? sugs.warning.default : (sugs.normal[arCond] || sugs.normal.default);
  grid.innerHTML = s.map(([icon,title,desc]) => `
    <div style="background:white;border:1.5px solid #e2e8f0;border-radius:12px;padding:14px;display:flex;align-items:flex-start;gap:10px">
      <span style="font-size:1.3rem">${icon}</span>
      <div><strong style="display:block;font-size:.85rem;color:#334155;margin-bottom:2px">${title}</strong><span style="font-size:.78rem;color:#94a3b8">${desc}</span></div>
    </div>`).join('');
}

// ─── SAVE LOG ───
async function arSaveLog() {
  if (!arBpmHistory.length) { showToast('Belum ada data!'); return; }
  const avg = Math.round(arBpmHistory.reduce((a,b)=>a+b,0)/arBpmHistory.length);
  const mx = Math.max(...arBpmHistory), mn = Math.min(...arBpmHistory);
  const r = arCondRanges[arCond];
  const status = avg > r.veryHigh || avg < r.veryLow ? 'danger' : avg > r.high || avg < r.low ? 'warning' : 'normal';
  const zones = { low:'Sangat Rendah', rest:'Istirahat Normal', fat:'Pembakaran Lemak', cardio:'Kardio', peak:'Puncak' };
  let zone = avg < 60 ? 'low' : avg < 100 ? 'rest' : avg < 130 ? 'fat' : avg < 160 ? 'cardio' : 'peak';
  const entry = { id:Date.now(), datetime:new Date().toLocaleString('id-ID'), bpm:avg, max:mx, min:mn, cond:arCond, condLabel:arCondLabels[arCond], zone:zones[zone], status };

  if (authToken) {
    try {
      const res = await apiPost('hr_log.php', {
        bpm: avg, max: mx, min: mn, cond: arCond, condLabel: arCondLabels[arCond], zone: zones[zone], status,
      });
      if (res.success) entry.id = res.data.id;
    } catch(e) { console.warn('Gagal simpan HR ke server', e); }
  } else {
    try { localStorage.setItem('healthedu_hr_log', JSON.stringify([entry, ...arLogData])); } catch(e) {}
  }

  arLogData.unshift(entry);
  arRenderLog(); arRenderTrend(); document.getElementById('arAICount').textContent = arLogData.length;
  arShowNotif(avg); arShowSuggestions(avg);
  showToast('✅ Data disimpan ke log!');
}

function arRenderLog() {
  const tbody = document.getElementById('arLogBody');
  const data = arLogFilter === 'all' ? arLogData : arLogData.filter(e => e.status === arLogFilter);
  if (!data.length) {
    tbody.innerHTML = `<tr><td colspan="6"><div class="log-empty-state"><i class="fas fa-book-medical"></i><p>Tidak ada data ${arLogFilter !== 'all' ? 'dengan filter ini' : ''}.</p></div></td></tr>`;
    return;
  }
  const statusLabel = { normal:'Normal', warning:'Perhatian', danger:'Bahaya!' };
  const statusColor = { normal:'background:#d1fae5;color:#065f46', warning:'background:#fef3c7;color:#92400e', danger:'background:#fee2e2;color:#991b1b' };
  tbody.innerHTML = data.map(e => `
    <tr style="border-bottom:1px solid #f1f5f9">
      <td style="padding:10px">${e.datetime}</td>
      <td style="padding:10px;font-weight:800;font-size:.95rem">${e.bpm} bpm</td>
      <td style="padding:10px;color:#94a3b8;font-size:.8rem">${e.min}–${e.max}</td>
      <td style="padding:10px"><span style="background:#f0fdf4;color:#059669;padding:3px 10px;border-radius:20px;font-size:.74rem;font-weight:600">${e.condLabel}</span></td>
      <td style="padding:10px"><span style="${statusColor[e.status]};padding:3px 10px;border-radius:20px;font-size:.74rem;font-weight:600">${statusLabel[e.status]}</span></td>
      <td style="padding:10px"><button onclick="arDelLog(${e.id})" style="background:none;border:none;color:#94a3b8;cursor:pointer;padding:4px 6px;border-radius:6px" title="Hapus"><i class="fas fa-trash"></i></button></td>
    </tr>`).join('');
}

async function arDelLog(id) {
  if (authToken) {
    try { await apiPost('hr_log.php', { action: 'delete', id }); }
    catch(e) { console.warn('Gagal hapus HR log', e); }
  } else {
    const local = JSON.parse(localStorage.getItem('healthedu_hr_log') || '[]').filter(e => e.id !== id);
    try { localStorage.setItem('healthedu_hr_log', JSON.stringify(local)); } catch(e) {}
  }

  arLogData = arLogData.filter(e => e.id !== id);
  arRenderLog(); arRenderTrend();
  document.getElementById('arAICount').textContent = arLogData.length;
}

function arFilterLog(f, btn) {
  arLogFilter = f;
  document.querySelectorAll('.ar-log-filter').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  arRenderLog();
}

function arExportCSV() {
  if (!arLogData.length) { showToast('Tidak ada data untuk export'); return; }
  const header = 'Tanggal,Waktu,BPM,Min,Maks,Kondisi,Zona,Status';
  const rows = arLogData.map(e => {
    const parts = e.datetime.split(' ');
    return `${parts[0]},${parts[1]||''},${e.bpm},${e.min},${e.max},${e.condLabel},${e.zone},${e.status}`;
  });
  const csv = [header, ...rows].join('\n');
  const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob);
  a.download = `heartrate_${new Date().toISOString().slice(0,10)}.csv`; a.click();
  showToast('✅ CSV di-download!');
}

// ─── TREND CHART ───
function arRenderTrend() {
  const canvas = document.getElementById('arTrendCanvas');
  const empty = document.getElementById('arTrendEmpty');
  if (!canvas) return;
  if (!arLogData.length) { if(empty) empty.style.display='flex'; return; }
  if (empty) empty.style.display='none';
  const recent = [...arLogData].slice(0,14).reverse();
  const w = canvas.parentElement.clientWidth || 500, h = 160;
  canvas.width = w; canvas.height = h;
  const c = canvas.getContext('2d');
  c.clearRect(0,0,w,h);
  const bpms = recent.map(e=>e.bpm);
  const mx = Math.max(...bpms,100), mn = Math.min(...bpms,60), range = mx-mn||40;
  const pad = {l:38,r:12,t:12,b:28};
  const cW = w-pad.l-pad.r, cH = h-pad.t-pad.b;
  c.strokeStyle='rgba(203,213,225,.5)'; c.lineWidth=1;
  [0,.5,1].forEach(r => {
    const y = pad.t + r*cH;
    c.beginPath(); c.moveTo(pad.l,y); c.lineTo(w-pad.r,y); c.stroke();
    c.fillStyle='#94a3b8'; c.font='10px Plus Jakarta Sans'; c.textAlign='right';
    c.fillText(Math.round(mx-r*range), pad.l-3, y+4);
  });
  const gX = i => pad.l+(i/(recent.length-1||1))*cW;
  const gY = v => pad.t+cH-((v-mn)/range)*cH;
  c.beginPath(); recent.forEach((e,i)=>i===0?c.moveTo(gX(i),gY(e.bpm)):c.lineTo(gX(i),gY(e.bpm)));
  c.lineTo(gX(recent.length-1),h-pad.b); c.lineTo(pad.l,h-pad.b); c.closePath();
  const g=c.createLinearGradient(0,pad.t,0,h); g.addColorStop(0,'rgba(239,68,68,.2)'); g.addColorStop(1,'rgba(239,68,68,0)');
  c.fillStyle=g; c.fill();
  c.beginPath(); recent.forEach((e,i)=>i===0?c.moveTo(gX(i),gY(e.bpm)):c.lineTo(gX(i),gY(e.bpm)));
  c.strokeStyle='#ef4444'; c.lineWidth=2.5; c.shadowColor='#ef4444'; c.shadowBlur=5; c.stroke();
  c.shadowBlur=0;
  recent.forEach((e,i)=>{
    const dc = e.status==='normal'?'#10b981':e.status==='warning'?'#f59e0b':'#ef4444';
    c.beginPath(); c.arc(gX(i),gY(e.bpm),4,0,Math.PI*2); c.fillStyle=dc; c.fill();
    c.strokeStyle='white'; c.lineWidth=1.5; c.stroke();
  });
  c.fillStyle='#94a3b8'; c.font='9px Plus Jakarta Sans'; c.textAlign='center';
  recent.forEach((e,i)=>{ if(i%2===0||recent.length<=7) c.fillText(e.datetime.split(' ')[0],gX(i),h-pad.b+14); });
}

// ─── ARTICLES DATA ───
const arArticles = [
  {
    emoji:'❤️', tag:'Heart Rate', bg:'linear-gradient(135deg,#fee2e2,#fecaca)',
    title:'Memahami Detak Jantung Normal',
    meta:'5 menit · Kesehatan Dasar',
    content:`<h4>Apa itu Detak Jantung?</h4>
    <p>Detak jantung (heart rate) adalah jumlah kali jantung berdetak per menit (bpm). Ini tanda vital yang mencerminkan kesehatan kardiovaskular.</p>
    <div style="background:#f0fdf4;border-left:4px solid #10b981;padding:14px 16px;border-radius:0 8px 8px 0;margin:12px 0"><p style="color:#065f46;font-weight:600;margin:0">💡 Normal orang dewasa saat istirahat: 60–100 bpm. Atlet terlatih bisa serendah 40 bpm karena jantung lebih efisien.</p></div>
    <h4>Faktor Pemengaruh HR</h4>
    <ul style="padding-left:18px">
      <li style="margin-bottom:6px"><strong>Usia:</strong> HR cenderung menurun seiring usia</li>
      <li style="margin-bottom:6px"><strong>Kebugaran:</strong> Orang fit memiliki HR istirahat lebih rendah</li>
      <li style="margin-bottom:6px"><strong>Suhu:</strong> Panas meningkatkan HR</li>
      <li style="margin-bottom:6px"><strong>Stres/Emosi:</strong> Kecemasan meningkatkan HR signifikan</li>
      <li style="margin-bottom:6px"><strong>Obat-obatan:</strong> Beberapa obat memengaruhi HR</li>
    </ul>
    <h4>Kapan Harus Khawatir?</h4>
    <p>Konsultasikan ke dokter jika HR istirahat konsisten >100 bpm (takikardi) atau <60 bpm (bradikardi) + gejala pusing, sesak, nyeri dada.</p>`
  },
  {
    emoji:'🏃', tag:'Olahraga', bg:'linear-gradient(135deg,#dbeafe,#bfdbfe)',
    title:'Zona HR untuk Latihan Efektif',
    meta:'7 menit · Kebugaran',
    content:`<h4>Mengapa Zona HR Penting?</h4>
    <p>Berlatih di zona HR yang tepat memaksimalkan manfaat sesuai tujuan: bakar lemak, daya tahan, atau performa.</p>
    <div style="background:#eff6ff;border-left:4px solid #3b82f6;padding:14px 16px;border-radius:0 8px 8px 0;margin:12px 0"><p style="color:#1e40af;font-weight:600;margin:0">📊 HR Maksimum = 220 – usia kamu. Semua zona dihitung dari persentase ini.</p></div>
    <h4>5 Zona Latihan</h4>
    <ul style="padding-left:18px">
      <li style="margin-bottom:8px"><strong>Zona 1 (50–60%):</strong> Pemulihan aktif, cocok pemanasan</li>
      <li style="margin-bottom:8px"><strong>Zona 2 (60–70%):</strong> Bakar lemak, bisa berbicara, durasi panjang</li>
      <li style="margin-bottom:8px"><strong>Zona 3 (70–80%):</strong> Aerobik, meningkatkan efisiensi kardio</li>
      <li style="margin-bottom:8px"><strong>Zona 4 (80–90%):</strong> Anaerobik, kecepatan dan kekuatan</li>
      <li style="margin-bottom:8px"><strong>Zona 5 (90–100%):</strong> Puncak, interval pendek saja</li>
    </ul>
    <h4>Rekomendasi Pemula</h4>
    <p>Mulai 60–70% HR maks, 20–30 menit, 3x seminggu. Tingkatkan bertahap setiap 2 minggu.</p>`
  },
  {
    emoji:'⚖️', tag:'BMI', bg:'linear-gradient(135deg,#d1fae5,#a7f3d0)',
    title:'BMI: Panduan Lengkap Indeks Massa Tubuh',
    meta:'6 menit · Nutrisi & Tubuh',
    content:`<h4>Apa itu BMI?</h4>
    <p>Body Mass Index (BMI) adalah ukuran yang menghitung rasio berat badan terhadap tinggi badan. Rumus: Berat (kg) ÷ Tinggi² (m).</p>
    <div style="background:#f0fdf4;border-left:4px solid #10b981;padding:14px 16px;border-radius:0 8px 8px 0;margin:12px 0"><p style="color:#065f46;font-weight:600;margin:0">📏 Kategori WHO: <18.5 (Kurang), 18.5–24.9 (Normal), 25–29.9 (Berlebih), ≥30 (Obesitas)</p></div>
    <h4>Keterbatasan BMI</h4>
    <ul style="padding-left:18px">
      <li style="margin-bottom:6px">Tidak membedakan otot vs lemak — atlet bisa BMI tinggi padahal sehat</li>
      <li style="margin-bottom:6px">Tidak mempertimbangkan distribusi lemak tubuh</li>
      <li style="margin-bottom:6px">Kurang akurat untuk lansia yang kehilangan massa otot</li>
    </ul>
    <h4>BMI dan Kesehatan Jantung</h4>
    <p>BMI tinggi berkorelasi dengan risiko hipertensi, diabetes tipe 2, dan penyakit jantung. Setiap kenaikan 1 unit BMI di atas normal meningkatkan HR istirahat rata-rata 1–2 bpm karena beban kerja jantung meningkat.</p>
    <h4>Tips Menjaga BMI Normal</h4>
    <p>Defisit kalori moderat (300–500 kkal), perbanyak protein dan serat, olahraga kombinasi kardio dan beban, tidur 7–9 jam. Gunakan kalkulator BMI kami untuk memantau progress!</p>`
  },
  {
    emoji:'🔥', tag:'TDEE', bg:'linear-gradient(135deg,#fef3c7,#fde68a)',
    title:'TDEE: Total Kebutuhan Kalori Harianmu',
    meta:'7 menit · Nutrisi',
    content:`<h4>Apa itu TDEE?</h4>
    <p>Total Daily Energy Expenditure (TDEE) adalah total kalori yang dibakar tubuh dalam sehari, termasuk aktivitas fisik. Ini berbeda dengan BMR (Basal Metabolic Rate) yang hanya kalori saat istirahat total.</p>
    <div style="background:#fffbeb;border-left:4px solid #f59e0b;padding:14px 16px;border-radius:0 8px 8px 0;margin:12px 0"><p style="color:#92400e;font-weight:600;margin:0">🔥 TDEE = BMR × Faktor Aktivitas. Rata-rata orang dewasa aktif: 2.000–2.500 kkal/hari.</p></div>
    <h4>Cara Menggunakan TDEE</h4>
    <ul style="padding-left:18px">
      <li style="margin-bottom:8px"><strong>Turun berat:</strong> Konsumsi TDEE – 300 sampai 500 kkal/hari</li>
      <li style="margin-bottom:8px"><strong>Jaga berat:</strong> Konsumsi = TDEE</li>
      <li style="margin-bottom:8px"><strong>Naik berat/massa otot:</strong> Konsumsi TDEE + 200 sampai 300 kkal/hari</li>
    </ul>
    <h4>TDEE dan Detak Jantung</h4>
    <p>Aktivitas fisik yang meningkatkan TDEE juga melatih efisiensi jantung. Orang dengan TDEE tinggi (banyak gerak) cenderung memiliki HR istirahat lebih rendah karena otot jantung lebih kuat. Gunakan kalkulator TDEE kami untuk mengetahui angka tepatmu!</p>`
  },
  {
    emoji:'💤', tag:'Tidur', bg:'linear-gradient(135deg,#fce7f3,#fbcfe8)',
    title:'HR Saat Tidur & Kualitas Tidur',
    meta:'5 menit · Pemulihan',
    content:`<h4>Detak Jantung Saat Tidur Normal</h4>
    <p>Selama tidur, HR biasanya turun 10–30% dari HR istirahat siang hari karena sistem saraf parasimpatis lebih aktif. Normal berkisar 40–80 bpm.</p>
    <div style="background:#fdf4ff;border-left:4px solid #a855f7;padding:14px 16px;border-radius:0 8px 8px 0;margin:12px 0"><p style="color:#7e22ce;font-weight:600;margin:0">🌙 Pada fase REM, HR bisa lebih tinggi dan tidak teratur — ini normal, terkait aktivitas mimpi.</p></div>
    <h4>Indikator dari HR Tidur</h4>
    <ul style="padding-left:18px">
      <li style="margin-bottom:8px"><strong>HR tidur >80 bpm:</strong> Bisa mengindikasikan stres, infeksi, atau sleep apnea</li>
      <li style="margin-bottom:8px"><strong>HR tidur <40 bpm:</strong> Normal pada atlet, perlu cek jika bukan atlet</li>
      <li style="margin-bottom:8px"><strong>HRV tinggi saat tidur:</strong> Tanda pemulihan yang baik</li>
    </ul>
    <h4>Tips Tidur Berkualitas</h4>
    <p>Jadwal tidur konsisten, hindari layar 1 jam sebelum tidur, suhu kamar 18–20°C, hindari kafein dan alkohol malam hari. HR tidur yang sehat adalah investasi kesehatan jantung jangka panjang.</p>`
  },
  {
    emoji:'🧘', tag:'Gaya Hidup', bg:'linear-gradient(135deg,#ede9fe,#ddd6fe)',
    title:'5 Cara Turunkan Detak Jantung Tinggi',
    meta:'4 menit · Wellness',
    content:`<h4>Teknik Pernapasan 4-7-8</h4>
    <p>Tarik napas 4 detik, tahan 7 detik, buang 8 detik. Ulangi 4 kali. Mengaktifkan sistem saraf parasimpatis yang memperlambat HR.</p>
    <div style="background:#f0fdf4;border-left:4px solid #10b981;padding:14px 16px;border-radius:0 8px 8px 0;margin:12px 0"><p style="color:#065f46;font-weight:600;margin:0">🧊 Celupkan wajah ke air dingin 30 detik — turunkan HR 10–25% via refleks menyelam mamalia.</p></div>
    <h4>Cara Praktis Lainnya</h4>
    <ul style="padding-left:18px">
      <li style="margin-bottom:6px">Minum segelas air dingin</li>
      <li style="margin-bottom:6px">Berbaring, angkat kaki lebih tinggi dari jantung</li>
      <li style="margin-bottom:6px">Meditasi atau relaksasi otot progresif</li>
      <li style="margin-bottom:6px">Kurangi kafein dan alkohol secara bertahap</li>
      <li style="margin-bottom:6px">Olahraga rutin untuk turunkan HR istirahat jangka panjang</li>
    </ul>`
  },
  {
    emoji:'☕', tag:'Nutrisi', bg:'linear-gradient(135deg,#fef9c3,#fef08a)',
    title:'Kafein dan Jantung: Berapa Batas Aman?',
    meta:'6 menit · Nutrisi',
    content:`<h4>Bagaimana Kafein Mempengaruhi HR?</h4>
    <p>Kafein memblokir adenosin (zat yang bikin ngantuk), meningkatkan adrenalin, dan mempercepat HR rata-rata 5–15 bpm.</p>
    <div style="background:#fffbeb;border-left:4px solid #f59e0b;padding:14px 16px;border-radius:0 8px 8px 0;margin:12px 0"><p style="color:#92400e;font-weight:600;margin:0">☕ Batas aman: 400mg kafein/hari (~4 cangkir kopi). Lebih dari itu: palpitasi, tremor, hipertensi.</p></div>
    <h4>Yang Perlu Ekstra Hati-hati</h4>
    <ul style="padding-left:18px">
      <li style="margin-bottom:6px">Penderita aritmia atau gangguan irama jantung</li>
      <li style="margin-bottom:6px">Penderita kecemasan atau serangan panik</li>
      <li style="margin-bottom:6px">Ibu hamil (batas 200mg/hari)</li>
      <li style="margin-bottom:6px">Remaja dan anak-anak</li>
    </ul>
    <h4>Tips Konsumsi Lebih Aman</h4>
    <p>Hindari kafein setelah pukul 14.00. Minum air bersamaan. Jangan kopi saat perut kosong. Perhatikan sumber tersembunyi: minuman energi, teh, cokelat, beberapa obat.</p>`
  },
  {
    emoji:'🤖', tag:'IoT', bg:'linear-gradient(135deg,#f0f9ff,#e0f2fe)',
    title:'IoT & Monitoring Jantung ESP32',
    meta:'8 menit · Teknologi',
    content:`<h4>Revolusi Monitoring Kesehatan</h4>
    <p>Sensor IoT seperti ESP32 + sensor pulse (KY-039/MAX30102) memungkinkan pemantauan HR real-time yang sebelumnya hanya di RS.</p>
    <div style="background:#eff6ff;border-left:4px solid #3b82f6;padding:14px 16px;border-radius:0 8px 8px 0;margin:12px 0"><p style="color:#1e40af;font-weight:600;margin:0">🌐 Sistem ini membaca sinyal PPG (Photoplethysmography) dari jari, mendeteksi perubahan volume darah setiap detak jantung.</p></div>
    <h4>Cara Kerja Sistem IoT HR Ini</h4>
    <ul style="padding-left:18px">
      <li style="margin-bottom:8px"><strong>Sensor KY-039:</strong> Membaca sinyal analog dari jari (pin ADC 34)</li>
      <li style="margin-bottom:8px"><strong>ESP32:</strong> Proses threshold detection + hitung BPM dari interval antar detak</li>
      <li style="margin-bottom:8px"><strong>WiFi API:</strong> Kirim data JSON ke endpoint /data setiap request</li>
      <li style="margin-bottom:8px"><strong>Web App:</strong> Polling setiap 1 detik, tampilkan real-time</li>
    </ul>
    <h4>Tips Akurasi Sensor</h4>
    <p>Letakkan jari dengan tekanan konsisten, hindari gerakan, pastikan cahaya ruangan cukup. Kalibrasi threshold (default 1750) sesuai kondisi sensor dan pencahayaan. Akurasi terbaik dalam kondisi diam.</p>`
  }
];

function renderArArticles() {
  const grid = document.getElementById('arArticleGrid');
  if (!grid || grid.children.length > 0) return;
  grid.innerHTML = arArticles.map((a,i) => `
    <div onclick="arOpenArticle(${i})" style="border-radius:12px;overflow:hidden;border:1.5px solid #e2e8f0;background:white;cursor:pointer;transition:all .2s" onmouseover="this.style.transform='translateY(-2px)';this.style.boxShadow='0 8px 24px rgba(0,0,0,.08)'" onmouseout="this.style.transform='none';this.style.boxShadow='none'">
      <div style="height:90px;display:flex;align-items:center;justify-content:center;font-size:2.4rem;background:${a.bg}">${a.emoji}</div>
      <div style="padding:14px 16px">
        <div style="font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#ef4444;margin-bottom:5px">${a.tag}</div>
        <div style="font-size:.88rem;font-weight:700;color:#334155;line-height:1.4;margin-bottom:6px">${a.title}</div>
        <div style="font-size:.74rem;color:#94a3b8">${a.meta}</div>
        <span style="display:inline-flex;align-items:center;gap:5px;margin-top:8px;font-size:.76rem;font-weight:600;color:#ef4444">Baca <i class="fas fa-arrow-right"></i></span>
      </div>
    </div>`).join('');
}

function arOpenArticle(idx) {
  const a = arArticles[idx];
  document.getElementById('arModalContent').innerHTML = `
    <div style="font-size:2.5rem;margin-bottom:12px">${a.emoji}</div>
    <div style="font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:#ef4444;margin-bottom:8px">${a.tag}</div>
    <h2 style="font-size:1.35rem;font-weight:800;color:#334155;margin-bottom:6px">${a.title}</h2>
    <div style="font-size:.78rem;color:#94a3b8;margin-bottom:20px">${a.meta}</div>
    <div style="font-size:.9rem;color:#64748b;line-height:1.7">${a.content}</div>`;
  document.getElementById('arModalBg').style.display = 'flex';
}

function arCloseModal(e) {
  if (e.target.id === 'arModalBg') document.getElementById('arModalBg').style.display = 'none';
}

// ─── INIT HR MODULE ───
document.addEventListener('DOMContentLoaded', () => {
  // Load saved HR log (fallback lokal jika belum login / belum sempat sync server)
  if (!authToken) {
    try {
      const saved = localStorage.getItem('healthedu_hr_log');
      if (saved) arLogData = JSON.parse(saved);
    } catch(e) {}
  }

  // Init canvas
  const cv = document.getElementById('arSigCanvas');
  if (cv) {
    const w = cv.offsetWidth || 300;
    cv.width = w; cv.height = 110;
    const c = cv.getContext('2d');
    c.fillStyle = '#0f172a'; c.fillRect(0,0,w,110);
    c.fillStyle = '#334155'; c.font = '12px Plus Jakarta Sans';
    c.textAlign = 'center';
    c.fillText('Hubungkan sensor untuk melihat sinyal', w/2, 58);
  }

  document.getElementById('arAICount').textContent = arLogData.length;
  arRenderLog();
});

// ─── EXTRA CSS via style tag ───
const arStyleEl = document.createElement('style');
arStyleEl.textContent = `
  .ar-cond-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(120px,1fr)); gap:8px; }
  .ar-cond-btn { display:flex;flex-direction:column;align-items:center;gap:7px;padding:14px 10px;border-radius:10px;border:2px solid #e2e8f0;background:white;cursor:pointer;font-family:inherit;text-align:center;transition:all .2s; }
  .ar-cond-btn:hover { border-color:#ef4444; background:#fff5f5; }
  .ar-cond-btn.active { border-color:#ef4444; background:#fff5f5; box-shadow:0 0 0 3px rgba(239,68,68,.1); }
  .ar-cond-btn i { font-size:1.3rem; }
  .ar-cond-btn span { font-size:.78rem;font-weight:600;color:#334155; }
  .ar-log-filter { padding:5px 12px;border-radius:20px;border:1.5px solid #e2e8f0;background:white;color:#64748b;font-size:.78rem;font-weight:600;cursor:pointer;transition:all .2s; }
  .ar-log-filter.active { border-color:#ef4444;background:#fff5f5;color:#dc2626; }
  @keyframes heartbeat { 0%,100%{transform:scale(1)} 14%{transform:scale(1.15)} 28%{transform:scale(1)} 42%{transform:scale(1.08)} 70%{transform:scale(1)} }
  @keyframes heartbeat-fast { 0%,100%{transform:scale(1)} 40%{transform:scale(1.2)} }
  @keyframes pulse-dot { 0%,100%{opacity:1} 50%{opacity:.3} }
  @keyframes slideUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
  @media(max-width:600px) {
    #arMonitorGrid { grid-template-columns:1fr !important; }
    #arMonitorGrid > div:last-child { grid-template-columns:repeat(2,1fr) !important; }
  }
`;
document.head.appendChild(arStyleEl);
